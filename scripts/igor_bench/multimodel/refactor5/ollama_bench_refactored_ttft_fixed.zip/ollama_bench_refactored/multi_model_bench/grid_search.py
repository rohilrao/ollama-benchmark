"""Building the (n x ctx x pad) parameter grid across every model, and
driving run_grid_search() over every point x rep — turning each
measure_point() result into flat, CSV-ready rows."""

import itertools

from .config import METRICS, SPREAD_METRICS


class GridSearchMixin:
    def _grid(self) -> list:
        per_model = [list(itertools.product(s["n_list"], s["ctx_list"], s["pad_list"]))
                     for s in self.model_specs]
        return [[{"model": s["model"], "n": n, "num_ctx": ctx, "pad_words": pad}
                 for s, (n, ctx, pad) in zip(self.model_specs, combo)]
                for combo in itertools.product(*per_model)]

    async def run_grid_search(self) -> list:
        """
        Runs every grid point `reps` times. Returns long-format rows: one row per
        (point, rep, model), so the schema is identical for 1 model or 5 and every
        cell is a scalar. Also populates self.response_rows with one row per
        individual request (see save_responses()).
        """
        grid = self._grid()
        self._log(f"Grid: {len(grid)} point(s) x {self.reps} rep(s) across "
                  f"{len(self.models)} model(s): {', '.join(self.models)}")
        self._log(f"Check the server env: OLLAMA_MAX_LOADED_MODELS >= {len(self.models)}, "
                  f"OLLAMA_NUM_PARALLEL >= {max(max(s['n_list']) for s in self.model_specs)}, "
                  "or Ollama will evict models / queue requests behind each other.")
        if len(grid) * self.reps > 200:
            self._log("  ⚠ that's a lot of full unload+load cycles — consider narrowing the lists.")

        rows = []
        self.response_rows = []
        prev_configs = None
        for p, configs in enumerate(grid, 1):
            for rep in range(1, self.reps + 1):
                skip_lifecycle = self.reuse_loaded_models and self._same_lifecycle(prev_configs, configs)
                self._log(f"[{p}/{len(grid)} rep {rep}/{self.reps}] {self._point_tag(configs)}"
                          + ("  (reusing loaded models)" if skip_lifecycle else ""))
                res = await self.measure_point(configs, skip_lifecycle=skip_lifecycle)
                # Only trust the next call to skip its lifecycle if these models
                # are known to still be resident; a runner crash, eviction, or
                # ctx reduction may have left VRAM in an unknown state, so any
                # status other than a clean "ok" or "cpu_offload" forces a full
                # unload/load/warmup cycle next time.
                prev_configs = configs if res["status"] in ("ok", "cpu_offload") else None
                tag = self._point_tag(configs)
                for rec in res.get("request_records", []):
                    self.response_rows.append({
                        "point": p, "rep": rep, "model": rec["model"],
                        "request_number": rec["request_number"], "response": rec["response"],
                        "char_length": rec["char_length"],
                        "response_time_sec": rec["response_time_sec"],
                        "ttft_thinking_sec": rec["ttft_thinking_sec"],
                        "ttft_content_sec": rec["ttft_content_sec"]})
                for cfg in configs:
                    pm = res["per_model"][cfg["model"]]
                    rows.append({
                        "point": p, "rep": rep, "point_tag": tag,
                        "model": cfg["model"], "n": cfg["n"],
                        "num_ctx": cfg["num_ctx"], "ctx_reported": pm.get("ctx_reported"),
                        "pad_words": cfg["pad_words"],
                        "point_status": res["status"], "model_status": pm["status"],
                        "vram_gb": pm.get("vram_gb"), "cpu_gb": pm.get("cpu_gb"),
                        "total_gb": pm.get("total_gb"),
                        "gpu_pct": pm.get("gpu_pct"), "cpu_pct": pm.get("cpu_pct"),
                        "vram_total_gb": res["vram_total_gb"],
                        "cpu_total_gb": res["cpu_total_gb"], "all_on_gpu": res["all_on_gpu"],
                        "load_sec": pm.get("load_sec"), "point_elapsed_sec": res["elapsed_sec"],
                        **{m: pm.get(m) for m in METRICS},
                        **{f"{m}{suf}": pm.get(f"{m}{suf}")
                           for m in SPREAD_METRICS for suf in ("_min", "_max")},
                        "output_tokens": pm.get("output_tokens"),
                        "thinking_chunks": pm.get("thinking_chunks"),
                        "content_chunks": pm.get("content_chunks"),
                        "n_ok": pm.get("n_ok"), "n_failed": pm.get("n_failed"),
                        "error": pm.get("error") or res["error"],
                    })
                if res["status"] == "ok":
                    def fmt_ttft(pm, base):
                        if pm[base] is None:
                            return "-"
                        return f"{pm[base]:.2f}s [{pm[base+'_min']:.2f}-{pm[base+'_max']:.2f}]"
                    detail = "  ".join(
                        "{m} load={l:.1f}s think={tk} content={c}".format(
                            m=c["model"],
                            l=res["per_model"][c["model"]]["load_sec"] or 0.0,
                            tk=fmt_ttft(res["per_model"][c["model"]], "ttft_thinking_sec"),
                            c=fmt_ttft(res["per_model"][c["model"]], "ttft_content_sec"))
                        for c in configs)
                    self._log(f"  ok  vram_total={res['vram_total_gb']:.2f}GB  "
                              f"elapsed={res['elapsed_sec']:.1f}s  {detail}")

        offload = [r for r in rows if r["point_status"] == "cpu_offload"]
        if offload:
            seen = {}
            for r in offload:
                seen.setdefault((r["point_tag"], r["model"]), r)
            self._log(f"\n{len({r['point'] for r in offload})} grid point(s) skipped "
                      "— model spilled to CPU:")
            for (tag, model), r in seen.items():
                if (r["cpu_gb"] or 0) > 0:
                    self._log(f"  {tag}  {model}: {r['cpu_gb']:.2f}GB of "
                              f"{r['total_gb']:.2f}GB on CPU ({r['cpu_pct']}%)")
        failed = {r["point"] for r in rows
                  if r["point_status"] not in ("ok", "cpu_offload")}
        if failed:
            self._log(f"{len(failed)}/{len(grid)} grid point(s) had failures.")
        return rows
