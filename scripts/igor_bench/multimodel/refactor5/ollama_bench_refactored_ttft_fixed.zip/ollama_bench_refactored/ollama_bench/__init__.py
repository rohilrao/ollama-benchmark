"""Shared plumbing for Ollama benchmarks: the client, prompt building, a
single streaming request that returns latency + response metrics, `ollama
ps` parsing, model load/unload, error classification/recovery, and CSV/plot
output.

Split into small purpose-specific modules (prompts, errors, residency,
lifecycle, requests, output), each holding a mixin composed onto
OllamaBenchmarkBase in base.py. Import from here as before:

    from ollama_bench import OllamaBenchmarkBase
"""

from .base import OllamaBenchmarkBase

__all__ = ["OllamaBenchmarkBase"]
