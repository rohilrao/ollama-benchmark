"""Spec normalization, results-directory/tag naming, and the blank-metrics
template used for rows that never got measured (skipped or failed points)."""

import os

from ollama_bench import OllamaBenchmarkBase

from .config import METRICS, SPREAD_METRICS


class SetupMixin:
    @staticmethod
    def _normalize(spec: dict) -> dict:
        return {"model": spec["model"],
                "n_list": list(spec.get("n_list") or [1]),
                "ctx_list": list(spec.get("ctx_list") or [None]),
                "pad_list": list(spec.get("pad_list") or [0])}

    @staticmethod
    def _safe(name: str) -> str:
        for ch in ":/\\":
            name = name.replace(ch, "-")
        return name

    @classmethod
    def _results_dir(cls, base: str, specs: list) -> str:
        return os.path.join(base, "_".join(cls._safe(s["model"]) for s in specs))

    @classmethod
    def _cfg_tag(cls, cfg: dict) -> str:
        """Compact, comma-free label for a single model's config."""
        ctx = cfg["num_ctx"]
        ctx_s = "def" if not ctx else (f"{ctx // 1024}k" if ctx % 1024 == 0 else str(ctx))
        pad = f"-p{cfg['pad_words']}" if cfg["pad_words"] else ""
        return f"{cls._safe(cfg['model']).split('-')[0][:14]}-n{cfg['n']}-c{ctx_s}{pad}"

    @classmethod
    def _point_tag(cls, configs: list) -> str:
        return "+".join(cls._cfg_tag(c) for c in configs)

    @staticmethod
    def _blank_metrics() -> dict:
        spread_keys = tuple(f"{m}{suf}" for m in SPREAD_METRICS for suf in ("_min", "_max"))
        return {k: None for k in METRICS + spread_keys +
                OllamaBenchmarkBase.REQUEST_COUNT_FIELDS}

    def _placement(self, bd: dict, load_sec: dict, name: str) -> dict:
        """Where the model physically sits, per `ollama ps`. Recorded on every
        row — including skipped ones, which is the whole point."""
        return {"load_sec": load_sec.get(name),
                "vram_gb": bd.get("vram_gb"), "total_gb": bd.get("total_gb"),
                "cpu_gb": bd.get("cpu_gb"), "gpu_pct": bd.get("gpu_pct"),
                "cpu_pct": bd.get("cpu_pct"), "ctx_reported": bd.get("ctx_reported")}
