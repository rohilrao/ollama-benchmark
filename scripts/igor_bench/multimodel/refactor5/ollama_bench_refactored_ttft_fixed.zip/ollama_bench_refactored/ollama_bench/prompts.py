"""Prompt construction shared by every benchmark request."""

import uuid


class PromptMixin:
    PROMPT_BASE = "Explain KV Cache in one sentence."
    LOREM = ("Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod "
             "tempor incididunt ut labore et dolore magna aliqua ut enim ad minim ") * 400

    def make_prompt(self, pad_words: int = 0) -> str:
        """Unique (cache-busting) prompt, optionally padded with filler words."""
        pad = " ".join(self.LOREM.split()[:pad_words]) + "\n" if pad_words else ""
        return f"[{uuid.uuid4().hex}]\n{pad}{self.PROMPT_BASE}"
