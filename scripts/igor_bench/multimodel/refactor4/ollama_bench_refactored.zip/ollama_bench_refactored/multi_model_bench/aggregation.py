"""Collapsing raw per-rep rows into one averaged row per (point, model), and
the plain-text config / per-request responses CSV writers."""

import os
import statistics

from ollama_bench import OllamaBenchmarkBase

from .config import METRICS, SPREAD_METRICS, CHAR_METRICS


class AggregationMixin:
    def average_reps(self, rows: list) -> list:
        """
        Collapse the raw rows to one row per (grid point, model), averaged over
        reps. Placement (VRAM/CPU/load) is averaged over every rep, so a point
        skipped for CPU offload still reports how much spilled; latency is
        averaged over successful reps only, so a failed rep can't drag the mean
        toward zero. `_std` columns are sample stdev, 0.0 when there's one rep.
        """
        placement = ("vram_gb", "cpu_gb", "total_gb", "gpu_pct", "cpu_pct",
                     "vram_total_gb", "cpu_total_gb", "load_sec", "ctx_reported")
        spread_cols = tuple(f"{m}{suf}" for m in SPREAD_METRICS for suf in ("_min", "_max"))
        perf = METRICS + spread_cols + CHAR_METRICS + ("point_elapsed_sec",) + \
            OllamaBenchmarkBase.REQUEST_COUNT_FIELDS
        spread = ("load_sec", "vram_gb", "wall_time_sec", "ttft_content_sec",
                  "tokens_per_sec", "batch_tokens_per_sec")

        def agg(reps, field, stat="mean"):
            vals = [r[field] for r in reps if r.get(field) is not None]
            if not vals:
                return None
            if stat == "std":
                return statistics.stdev(vals) if len(vals) > 1 else 0.0
            # A column that is itself a min/max across a batch (e.g. the
            # SPREAD_METRICS "*_min"/"*_max" columns) should stay a true
            # min/max across reps too — averaging minimums/maximums together
            # would blur the very extremes they exist to surface.
            if field.endswith("_min"):
                return min(vals)
            if field.endswith("_max"):
                return max(vals)
            return statistics.mean(vals)

        groups = {}
        for r in rows:
            groups.setdefault((r["point"], r["model"]), []).append(r)

        out = []
        for (point, model), reps in sorted(groups.items()):
            first = reps[0]
            ok = [r for r in reps if r["model_status"] in ("ok", "partial_failure")]
            row = {"point": point, "point_tag": first["point_tag"], "model": model,
                   "n": first["n"], "num_ctx": first["num_ctx"], "pad_words": first["pad_words"],
                   "reps": len(reps), "reps_ok": len(ok),
                   "statuses": ";".join(sorted({r["model_status"] for r in reps})),
                   "all_on_gpu": all(bool(r["all_on_gpu"]) for r in reps)}
            row.update({f: agg(reps, f) for f in placement})
            row.update({f: agg(ok, f) for f in perf})
            row.update({f + "_std": agg(ok if f in perf else reps, f, "std") for f in spread})
            row["requests_ok"] = sum(r["n_ok"] or 0 for r in reps)
            row["requests_failed"] = sum(r["n_failed"] or 0 for r in reps)
            row["error"] = next((r["error"] for r in reps if r["error"]), None)
            out.append(row)
        return out

    def save_averaged(self, rows: list, filename: str = "results_avg.csv"):
        self.save_csv(self.average_reps(rows), filename)

    def save_responses(self, filename: str = "responses.csv"):
        """Every individual request's full text response, one row each —
        populated by run_grid_search(). Point/rep/model/request_number let a
        row be traced back to the exact request that produced it."""
        self.save_csv(getattr(self, "response_rows", []), filename)

    def save_config(self, filename: str = "config.txt"):
        """Plain-text record of what was actually swept, dropped in the results
        folder alongside the CSVs — so a run is self-describing without having
        to reread the script that produced it."""
        lines = [f"host: {self.host}",
                 f"reps: {self.reps}",
                 f"request_timeout_sec: {self.request_timeout}",
                 f"load_timeout_sec: {self.load_timeout}",
                 f"keep_alive: {self.keep_alive}",
                 f"min_gpu_pct: {self.min_gpu_pct}",
                 f"skip_on_cpu_offload: {self.skip_on_cpu_offload}",
                 "", "models:"]
        for s in self.model_specs:
            lines.append(f"  {s['model']}")
            lines.append(f"    n_list:   {s['n_list']}")
            lines.append(f"    ctx_list: {s['ctx_list']}")
            lines.append(f"    pad_list: {s['pad_list']}")
        n_points = 1
        for s in self.model_specs:
            n_points *= len(s["n_list"]) * len(s["ctx_list"]) * len(s["pad_list"])
        lines += ["", f"grid points: {n_points}", f"total measurements (points x reps): {n_points * self.reps}"]

        path = os.path.join(self.output_dir, filename)
        with open(path, "w") as f:
            f.write("\n".join(lines) + "\n")
        self._log(f"Saved config → {path}")
