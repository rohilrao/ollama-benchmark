"""Error classification: turning an exception from an Ollama call into a
(status, message) pair the grid-search logic can act on without re-raising."""

import asyncio


class ErrorClassificationMixin:
    # Case-insensitive substrings meaning the llama runner crashed or OOM'd,
    # as opposed to a generic HTTP error.
    OOM_SIGNATURES = (
        "llama runner process has terminated",
        "out of memory",
        "cudamalloc",
        "failed to allocate",
        "llama_new_context_with_model failed",
    )

    def _classify_error(self, exc: Exception) -> tuple:
        """(status, message). Never raises."""
        if isinstance(exc, asyncio.TimeoutError):
            return "timeout", str(exc) or f"exceeded request_timeout of {self.request_timeout}s"

        message = str(exc)
        detail = getattr(exc, "error", None)  # ollama.ResponseError carries the server message here
        if detail:
            message = f"{message} | {detail}"
        low = message.lower()

        if any(sig in low for sig in self.OOM_SIGNATURES):
            return "oom_or_runner_crash", message
        if "connection" in low or isinstance(exc, ConnectionError):
            return "connection_error", message
        if getattr(exc, "status_code", None) == 500:
            return "server_error_500", message
        return "unknown_error", message
