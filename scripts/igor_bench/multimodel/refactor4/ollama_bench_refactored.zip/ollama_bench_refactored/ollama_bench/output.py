"""CSV and plot saving helpers shared by every benchmark."""

import csv
import os

import matplotlib
matplotlib.use("Agg")  # headless boxes / over ssh
import matplotlib.pyplot as plt


class OutputMixin:
    @staticmethod
    def _csv_safe(v):
        """Keep commas and newlines out of cells so the CSV stays column-aligned."""
        if isinstance(v, str):
            return v.replace(",", ";").replace("\n", " ").replace("\r", " ").strip()
        if isinstance(v, float):
            return round(v, 4)
        return v

    def save_csv(self, rows: list, filename: str):
        if not rows:
            self._log(f"No rows to save for {filename}; skipping.")
            return
        path = os.path.join(self.output_dir, filename)
        fieldnames = list(dict.fromkeys(k for row in rows for k in row))
        with open(path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows({k: self._csv_safe(v) for k, v in r.items()} for r in rows)
        self._log(f"Saved CSV → {path}")

    def _save_plot(self, fig, filename: str):
        path = os.path.join(self.output_dir, filename)
        fig.tight_layout()
        fig.savefig(path, dpi=150)
        plt.close(fig)
        self._log(f"Saved plot → {path}")
