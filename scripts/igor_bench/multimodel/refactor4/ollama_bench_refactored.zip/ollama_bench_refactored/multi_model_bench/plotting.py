"""Plotting: stacked per-model VRAM per grid point, and one latency line per
model for any metric in PLOTTABLE."""

import statistics

import matplotlib
matplotlib.use("Agg")  # headless boxes / over ssh
import matplotlib.pyplot as plt

from .config import PLOTTABLE


class PlottingMixin:
    def _points(self, rows: list, need: str) -> tuple:
        """(ordered point tags, {model: [value per point]}) averaged over reps."""
        ok = [r for r in rows if r.get(need) is not None and r["model_status"] in ("ok", "partial_failure")]
        if not ok:
            return [], {}
        tags = list(dict.fromkeys(r["point_tag"] for r in sorted(ok, key=lambda r: r["point"])))
        series = {}
        for model in self.models:
            vals = []
            for tag in tags:
                v = [r[need] for r in ok if r["point_tag"] == tag and r["model"] == model]
                vals.append(statistics.mean(v) if v else float("nan"))
            series[model] = vals
        return tags, series

    def plot_vram(self, rows: list, filename: str = "vram.png"):
        """Stacked per-model VRAM per grid point. Works for any number of models."""
        tags, series = self._points(rows, "vram_gb")
        if not tags:
            self._log("No successful VRAM measurements to plot.")
            return
        fig, ax = plt.subplots(figsize=(max(8, 1.2 * len(tags)), 6))
        bottom = [0.0] * len(tags)
        for model, vals in series.items():
            vals = [0.0 if v != v else v for v in vals]  # NaN -> 0 for stacking
            ax.bar(tags, vals, bottom=bottom, label=model)
            bottom = [b + v for b, v in zip(bottom, vals)]
        ax.set_title(f"VRAM with {len(self.models)} model(s) co-resident")
        ax.set_ylabel("VRAM used (GB)")
        ax.set_xlabel("Grid point")
        ax.tick_params(axis="x", rotation=30)
        for label in ax.get_xticklabels():
            label.set_ha("right")
        ax.grid(True, axis="y", alpha=0.3)
        ax.legend(fontsize=8)
        self._save_plot(fig, filename)

    def plot_latency(self, rows: list, metric: str = "ttft_sec", filename: str = None):
        """One line per model across grid points, for any latency metric."""
        if metric not in PLOTTABLE:
            self._log(f"Unknown metric '{metric}'; expected one of {sorted(PLOTTABLE)}.")
            return
        tags, series = self._points(rows, metric)
        if not tags:
            self._log(f"No successful {metric} measurements to plot.")
            return
        fig, ax = plt.subplots(figsize=(max(8, 1.2 * len(tags)), 6))
        for model, vals in series.items():
            ax.plot(tags, vals, marker="o", label=model)
        ax.set_title(f"{metric} under concurrent load")
        ax.set_ylabel(metric)
        ax.set_xlabel("Grid point")
        ax.set_ylim(bottom=0)
        ax.tick_params(axis="x", rotation=30)
        for label in ax.get_xticklabels():
            label.set_ha("right")
        ax.grid(True, alpha=0.3)
        ax.legend(fontsize=8)
        self._save_plot(fig, filename or f"latency_{metric}.png")

    def plot_all(self, rows: list):
        self.plot_vram(rows)
        for metric in PLOTTABLE:
            self.plot_latency(rows, metric)
