"""One streaming generation request: timing, token accounting, and the
accumulated response text — the unit every grid-search measurement is built
from."""

import time


class RequestMixin:
    # Canonical schema of stream_request()'s numeric return values. Other
    # modules (e.g. multi_model_bench) import these instead of re-typing the
    # same key strings, so the two can't drift out of sync.
    REQUEST_METRIC_FIELDS = ("wall_time_sec", "ttft_sec", "ttft_thinking_sec",
                             "ttft_content_sec", "tokens_per_sec")
    REQUEST_COUNT_FIELDS = ("output_tokens", "thinking_tokens", "content_tokens")

    async def stream_request(self, model: str, i: int, num_ctx: int = None,
                             pad_words: int = 0, gate=None) -> dict:
        """
        One streaming request, returning wall time, time-to-first-thinking-token,
        time-to-first-content-token, tok/s, thinking vs content chunk counts, and
        the full accumulated response text. Reasoning models stream thinking
        before content, so the two TTFTs can differ a lot — "time to first
        token" usually means the content one.

        If `gate` is given the request blocks on it before starting, so every
        request across every model leaves the line at the same instant and the
        clock starts after the gate — not at task-creation time.
        """
        options = {"temperature": 0.0}
        if num_ctx:
            options["num_ctx"] = num_ctx
        prompt = self.make_prompt(pad_words)  # built before the gate; not timed

        if gate is not None:
            await gate.wait()

        out_tokens = eval_ns = thinking = content = idx = 0
        ttft_thinking = ttft_content = None
        full_response = ""
        start = time.perf_counter()
        async for chunk in await self.client.chat(
            model=model, messages=[{"role": "user", "content": prompt}],
            stream=True, options=options, keep_alive=self.keep_alive,
        ):
            msg = chunk.get("message", {}) or {}
            think_tok, content_tok = msg.get("thinking") or "", msg.get("content") or ""
            if think_tok:
                thinking += 1
                if ttft_thinking is None:
                    ttft_thinking = time.perf_counter() - start
            if content_tok:
                content += 1
                full_response += content_tok
                if ttft_content is None:
                    ttft_content = time.perf_counter() - start
            if think_tok or content_tok:
                idx += 1
                if self.log_tokens:
                    kind = "thinking" if think_tok else "content"
                    self._log(f"[{model} R{i} T{idx} {kind}]: {(think_tok or content_tok).strip()}",
                              end=" | ", flush=True)
            if chunk.get("done"):
                out_tokens = chunk.get("eval_count", 0) or 0
                eval_ns = chunk.get("eval_duration", 0) or 0

        wall = time.perf_counter() - start
        # Non-reasoning models never set ttft_thinking; fall back to whichever
        # arrived, then wall time, so downstream code always gets a float.
        ttft_first = next((t for t in (ttft_thinking, ttft_content) if t is not None), wall)
        metrics = {"wall_time_sec": wall,
                   "ttft_sec": ttft_first,
                   "ttft_thinking_sec": ttft_thinking if ttft_thinking is not None else ttft_first,
                   "ttft_content_sec": ttft_content if ttft_content is not None else wall,
                   "tokens_per_sec": out_tokens / (eval_ns / 1e9) if eval_ns > 0 else 0.0}
        counts = {"output_tokens": out_tokens, "thinking_tokens": thinking, "content_tokens": content}
        return {**metrics, **counts,
                "request_index": i,
                "full_response": full_response,
                "char_length": len(full_response)}
