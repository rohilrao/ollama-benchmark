"""One grid point: get every model resident at the right num_ctx, verify
placement, warm up, fire the concurrent request batch, and aggregate
per-model latency/response metrics. This is the co-residency benchmark's
core measurement logic — everything else in the package is either building
the grid that feeds this, or reporting on what it returns."""

import asyncio
import statistics
import time

from .config import SPREAD_METRICS


class MeasurementMixin:
    @staticmethod
    def _same_lifecycle(prev: list, configs: list) -> bool:
        """
        True when `prev` and `configs` would leave every model resident at the
        same num_ctx, so a fresh unload/load/warmup cycle is unnecessary. Only
        num_ctx matters here — n and pad_words affect the request batch, not
        what's loaded in VRAM.
        """
        if prev is None:
            return False
        prev_ctx = {c["model"]: c["num_ctx"] for c in prev}
        cur_ctx = {c["model"]: c["num_ctx"] for c in configs}
        return prev_ctx == cur_ctx

    async def measure_point(self, configs: list, skip_lifecycle: bool = False) -> dict:
        """
        configs: [{"model", "n", "num_ctx", "pad_words"}, ...], one per model.
        Returns {status, error, elapsed_sec, vram_total_gb, cpu_total_gb,
                 all_on_gpu, per_model: {name: {...}}, request_records: [...]}.
        Never raises.

        skip_lifecycle=True means the caller has already determined every
        model in `configs` is resident at the right num_ctx from the previous
        call (e.g. another rep of the same grid point), so unload/load/warmup
        are skipped entirely — only the placement check still runs, to make
        sure nothing was evicted behind our back.
        """
        blank = {c["model"]: {"status": "not_run", "n_ok": 0, "n_failed": 0, "error": None,
                              **self._blank_metrics()} for c in configs}

        if skip_lifecycle:
            load_sec = {c["model"]: 0.0 for c in configs}
        else:
            await self.unload(self.models)

            # ── load phase — nothing is timed until every model is resident ──
            load_sec = {}
            for cfg in configs:
                t = time.perf_counter()
                try:
                    await self.load(cfg["model"], cfg["num_ctx"])
                except Exception as e:
                    status, msg = self._classify_error(e)
                    self._log(f"  ✗ load failed for {cfg['model']}: {status} — {msg}")
                    await self.recover(self.models)
                    return {"status": status, "error": f"load_failed[{cfg['model']}]: {msg}",
                            "elapsed_sec": None, "vram_total_gb": None, "cpu_total_gb": None,
                            "all_on_gpu": None, "per_model": blank, "request_records": []}
                load_sec[cfg["model"]] = time.perf_counter() - t

        # ── placement check — refuse to bench a point that didn't fit ────
        loaded = await self.ps_breakdown(self.models)
        placed = {c["model"]: {**blank[c["model"]],
                               **self._placement(loaded["per_model"][c["model"]], load_sec, c["model"])}
                  for c in configs}
        head = {"elapsed_sec": None, "vram_total_gb": loaded["vram_total_gb"],
                "cpu_total_gb": loaded["cpu_total_gb"], "all_on_gpu": loaded["all_fully_on_gpu"]}

        missing = [m for m, p in loaded["per_model"].items() if not p["loaded"]]
        if missing:
            self._log(f"  ✗ not resident after loading: {' '.join(missing)}")
            self._log("    Ollama evicted them — raise OLLAMA_MAX_LOADED_MODELS or free VRAM. "
                      "Measuring now would time a load, not co-residency.")
            for m in missing:
                placed[m]["status"] = "not_loaded"
            return {"status": "eviction_or_oom", "error": f"not_resident: {' '.join(missing)}",
                    **head, "per_model": placed, "request_records": []}

        # Ollama retries a load that OOM'd with a smaller context (sched.go
        # reduceAutoNumCtxForLoadOOM) and returns success, so the runner can be
        # holding a context we never asked for. `ollama ps` reports what it
        # actually loaded; anything smaller than requested makes the point a
        # measurement of a different configuration.
        shrunk = {}
        for c in configs:
            got = loaded["per_model"][c["model"]]["ctx_reported"]
            if c["num_ctx"] and got and got < c["num_ctx"]:
                shrunk[c["model"]] = (got, c["num_ctx"])
        if shrunk:
            detail = " ".join(f"{m}: loaded {got} not {want}" for m, (got, want) in shrunk.items())
            self._log(f"  ✗ context silently reduced after a load OOM — skipping: {detail}")
            for m in shrunk:
                placed[m]["status"] = "ctx_reduced"
            return {"status": "ctx_reduced", "error": f"ctx_reduced: {detail}",
                    **head, "per_model": placed, "request_records": []}

        # A model that spilled into system RAM is running partly on CPU: its
        # numbers measure the spill, not the GPU, and generation can take
        # minutes-to-forever. Record how much went to CPU and skip the point.
        spilled = {m: p for m, p in loaded["per_model"].items()
                   if p["gpu_pct"] is not None and p["gpu_pct"] < self.min_gpu_pct}
        if spilled:
            detail = " ".join(f"{m}={p['cpu_gb']:.2f}GB/{p['cpu_pct']}% on CPU"
                              for m, p in spilled.items())
            if self.skip_on_cpu_offload:
                self._log(f"  ✗ CPU offload — skipping benchmark for this point: {detail}")
                for m in spilled:
                    placed[m]["status"] = "cpu_offload"
                return {"status": "cpu_offload", "error": f"cpu_offload: {detail}",
                        **head, "per_model": placed, "request_records": []}
            self._log(f"  ⚠ CPU offload (benching anyway, skip_on_cpu_offload=False): {detail}")

        # ── warmup — resident is not warm; do this before anything is timed.
        # The first generation after a load still pays for CUDA kernel JIT /
        # cache warming, which otherwise inflates TTFT for whichever request
        # happens to run first. Skipped along with load/unload when the
        # previous call already warmed these exact models at this num_ctx.
        if not skip_lifecycle:
            await asyncio.gather(*(self.warmup(c["model"], c["num_ctx"]) for c in configs))

        # ── generation phase — all requests released together ────────────
        gate = asyncio.Event()
        tasks, owners = [], []
        for cfg in configs:
            for i in range(1, cfg["n"] + 1):
                tasks.append(asyncio.create_task(asyncio.wait_for(
                    self.stream_request(cfg["model"], i, cfg["num_ctx"], cfg["pad_words"], gate),
                    timeout=self.request_timeout)))
                owners.append(cfg["model"])

        stop = asyncio.Event()
        sampler = asyncio.create_task(self._sample_vram(stop, loaded))
        await asyncio.sleep(0)  # let every task reach the gate before it opens

        start = time.perf_counter()
        gate.set()
        results = await asyncio.gather(*tasks, return_exceptions=True)
        elapsed = time.perf_counter() - start
        stop.set()
        peak = await sampler

        # ── per-model aggregation ────────────────────────────────────────
        per_model, failures, request_records = {}, [], []
        for cfg in configs:
            name = cfg["model"]
            mine = [r for r, owner in zip(results, owners) if owner == name]
            errs = [r for r in mine if isinstance(r, Exception)]
            oks = [r for r in mine if not isinstance(r, Exception)]

            row = {"status": "ok", "n_ok": len(oks), "n_failed": len(errs), "error": None,
                   **self._placement(peak["per_model"].get(name, {}), load_sec, name)}
            if errs:
                status, msg = self._classify_error(errs[0])
                row["status"] = "partial_failure" if oks else status
                row["error"] = msg
                failures.append(f"{name}: {status}")

            if oks:
                # span, not point elapsed: a model that finishes early shouldn't
                # be charged for the slower model's tail.
                span = max(r["wall_time_sec"] for r in oks)
                tokens = sum(r["output_tokens"] for r in oks)
                row.update({m: statistics.mean(r[m] for r in oks)
                            for m in ("wall_time_sec", "ttft_sec", "ttft_thinking_sec",
                                     "ttft_content_sec", "tokens_per_sec")})
                # Spread across the N requests in this batch — the mean alone
                # hides whether one request straggled far behind the rest.
                for m in SPREAD_METRICS:
                    row[f"{m}_min"] = min(r[m] for r in oks)
                    row[f"{m}_max"] = max(r[m] for r in oks)
                # Same idea for response length: which request came back
                # shortest/longest, and how long that particular request took
                # to complete, including its own TTFTs.
                shortest = min(oks, key=lambda r: r["char_length"])
                longest = max(oks, key=lambda r: r["char_length"])
                row.update({"min_chars": shortest["char_length"],
                            "min_chars_time_sec": shortest["wall_time_sec"],
                            "min_chars_ttft_thinking_sec": shortest["ttft_thinking_sec"],
                            "min_chars_ttft_content_sec": shortest["ttft_content_sec"],
                            "max_chars": longest["char_length"],
                            "max_chars_time_sec": longest["wall_time_sec"],
                            "max_chars_ttft_thinking_sec": longest["ttft_thinking_sec"],
                            "max_chars_ttft_content_sec": longest["ttft_content_sec"]})
                row.update({"batch_tokens_per_sec": tokens / span if span > 0 else 0.0,
                            "output_tokens": tokens,
                            "thinking_tokens": statistics.mean(r["thinking_tokens"] for r in oks),
                            "content_tokens": statistics.mean(r["content_tokens"] for r in oks)})
                if tokens == 0:
                    # Request "succeeded" but produced nothing — a silent runner
                    # failure, which would otherwise land in the CSV as a very
                    # fast, very good-looking row.
                    row["status"] = "empty_response"
                    row["error"] = "completed with 0 output tokens"
                    failures.append(f"{name}: empty_response")
                request_records.extend({"model": name, "request_number": r["request_index"],
                                        "response": r["full_response"],
                                        "char_length": r["char_length"],
                                        "response_time_sec": r["wall_time_sec"]} for r in oks)
            else:
                row.update(self._blank_metrics())
            per_model[name] = row

        if failures:
            self._log(f"  ✗ {self._point_tag(configs)}: {'; '.join(failures)}")
            await self.recover(self.models)

        return {"status": "ok" if not failures else "partial_or_full_failure",
                "error": "; ".join(failures) or None,
                "elapsed_sec": elapsed,
                "vram_total_gb": peak["vram_total_gb"],
                "cpu_total_gb": peak["cpu_total_gb"],
                "all_on_gpu": peak["all_fully_on_gpu"],
                "per_model": per_model,
                "request_records": request_records}

    async def _sample_vram(self, stop: asyncio.Event, baseline: dict) -> dict:
        """
        Poll `ollama ps` during generation and keep the highest total seen. Note
        that size_vram is a load-time allocation, not a live reading, so this
        will not show the KV cache filling — it catches a model being evicted or
        reloaded mid-run, which would otherwise go unnoticed.
        """
        peak = baseline
        while not stop.is_set():
            try:
                await asyncio.wait_for(stop.wait(), timeout=self.vram_sample_interval)
                break
            except asyncio.TimeoutError:
                pass
            try:
                bd = await self.ps_breakdown(self.models)
                if bd["vram_total_gb"] > peak["vram_total_gb"]:
                    peak = bd
            except Exception:
                pass  # sampling must never break a measurement
        return peak
