"""Model residency lifecycle: unload, load, warmup, and post-failure recovery.

Relies on ResidencyMixin.ps_breakdown() to verify state, so this mixin is
meant to be composed alongside it (see base.OllamaBenchmarkBase).
"""

import asyncio
import time


class LifecycleMixin:
    async def unload(self, models: list, settle: float = 2.0, verify_timeout: float = 60.0):
        """
        Evict every model and wait until `ollama ps` confirms it is gone, so one
        grid point never inherits the previous point's runner or its VRAM. A
        fixed sleep isn't enough: freeing a large model can take longer than it,
        and the next load would then be measured against stale VRAM.
        """
        for name in models:
            try:
                await asyncio.wait_for(
                    self.client.chat(model=name, messages=[], keep_alive=0), timeout=60)
            except Exception as e:
                self._log(f"  unload of {name} failed (ignored): {e}")

        deadline = time.perf_counter() + verify_timeout
        while True:
            await asyncio.sleep(settle)
            try:
                resident = [m for m, p in (await self.ps_breakdown(models))["per_model"].items()
                            if p["loaded"]]
            except Exception:
                return  # can't verify; the residency check after loading will still catch trouble
            if not resident:
                return
            if time.perf_counter() > deadline:
                self._log(f"  ⚠ still resident {verify_timeout}s after unload: {' '.join(resident)}")
                return

    async def load(self, model: str, num_ctx: int = None):
        """
        Force `model` resident *without generating*: an empty messages array is a
        load-only request. num_ctx is passed here as well as on the real requests,
        because a later request with a different num_ctx makes Ollama reload the
        runner — which would put a model load back inside the timed window.
        """
        options = {"num_ctx": num_ctx} if num_ctx else {}
        try:
            await asyncio.wait_for(
                self.client.chat(model=model, messages=[], keep_alive=self.keep_alive, options=options),
                timeout=self.load_timeout,
            )
        except asyncio.TimeoutError:
            # A load that never returns is the usual shape of an OOM that Ollama
            # neither reports nor recovers from; bound it and move on.
            raise asyncio.TimeoutError(
                f"load of {model} (num_ctx={num_ctx}) exceeded load_timeout of {self.load_timeout}s")

    async def warmup(self, model: str, num_ctx: int = None):
        """
        One throwaway generation, on top of `load()`. Being resident isn't the
        same as being warm: the first real generation after a load still pays
        for CUDA kernel JIT / cuBLAS autotune / cache warming that later
        generations don't, which otherwise shows up as an inflated TTFT on
        whichever request happens to run first. Errors are logged, not raised —
        a failed warmup shouldn't lose an otherwise-good grid point.
        """
        options = {"num_ctx": num_ctx} if num_ctx else {}
        try:
            async for _ in await self.client.chat(
                model=model, messages=[{"role": "user", "content": "hello"}],
                stream=True, options=options, keep_alive=self.keep_alive,
            ):
                pass
        except Exception as e:
            self._log(f"  warmup for {model} failed (ignored): {e}")

    async def recover(self, models: list, sleep: float = 3.0):
        """Best-effort post-failure recovery; logged, never raised."""
        self._log(f"  recovering (sleep {sleep}s, then pinging {len(models)} model(s))...")
        await asyncio.sleep(sleep)
        for name in models:
            try:
                await asyncio.wait_for(
                    self.client.chat(model=name, messages=[{"role": "user", "content": "ping"}],
                                     keep_alive=0),
                    timeout=60)
            except Exception as e:
                self._log(f"  recovery ping for {name} failed ({e}); continuing anyway.")
