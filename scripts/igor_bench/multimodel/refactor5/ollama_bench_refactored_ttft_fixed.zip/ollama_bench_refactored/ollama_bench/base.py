"""OllamaBenchmarkBase: owns the client/config every benchmark run needs and
composes the shared plumbing mixins (prompts, error classification,
residency, lifecycle, requests, output) into one class. Grid-search-specific
behaviour — running many models across many configs — lives in the
multi_model_bench package, which subclasses this."""

import os

import ollama

from .prompts import PromptMixin
from .errors import ErrorClassificationMixin
from .residency import ResidencyMixin
from .lifecycle import LifecycleMixin
from .requests import RequestMixin
from .output import OutputMixin


class OllamaBenchmarkBase(PromptMixin, ErrorClassificationMixin, ResidencyMixin,
                          LifecycleMixin, RequestMixin, OutputMixin):
    def __init__(self, host: str, output_dir: str = ".", verbose: bool = True,
                 request_timeout: float = 240.0, load_timeout: float = 900.0,
                 keep_alive: str = "30m", log_tokens: bool = False):
        self.host = host
        self.output_dir = output_dir
        self.verbose = verbose
        self.request_timeout = request_timeout
        self.load_timeout = load_timeout      # loading a 235B from cold takes minutes
        self.keep_alive = keep_alive          # must outlive a grid point or models get evicted
        self.log_tokens = log_tokens          # per-token logging is unusable at n=40
        os.makedirs(self.output_dir, exist_ok=True)
        self.client = ollama.AsyncClient(host=host)

    def _log(self, msg="", end="\n", flush=False):
        if self.verbose:
            print(msg, end=end, flush=flush)
