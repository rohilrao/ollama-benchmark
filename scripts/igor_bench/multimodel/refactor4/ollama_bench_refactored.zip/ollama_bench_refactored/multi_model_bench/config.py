"""Metric-name constants shared across measurement, aggregation, and
plotting, so every module agrees on the same column names."""

from ollama_bench import OllamaBenchmarkBase

# Sourced from OllamaBenchmarkBase.REQUEST_METRIC_FIELDS (stream_request's own
# return schema) instead of re-typing the same key strings here, so the two
# can't drift out of sync. "batch_tokens_per_sec" is the one metric computed
# at aggregation time rather than per-request.
METRICS = OllamaBenchmarkBase.REQUEST_METRIC_FIELDS + ("batch_tokens_per_sec",)
SPREAD_METRICS = ("ttft_thinking_sec", "ttft_content_sec")   # get _min/_max across the batch
# One row per grid point+model: the shortest/longest response in the batch,
# plus that same request's completion time and TTFTs — so a suspiciously
# short/long response can be traced to how fast it started, not just its length.
CHAR_METRICS = ("min_chars", "min_chars_time_sec",
                "min_chars_ttft_thinking_sec", "min_chars_ttft_content_sec",
                "max_chars", "max_chars_time_sec",
                "max_chars_ttft_thinking_sec", "max_chars_ttft_content_sec")
PLOTTABLE = METRICS + ("load_sec",)   # load_sec is measured per model, not per request
