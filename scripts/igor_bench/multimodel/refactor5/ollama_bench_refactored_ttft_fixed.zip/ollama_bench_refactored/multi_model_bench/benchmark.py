"""MultiModelBenchmark: the public class users construct. It composes the
grid-search mixins (setup, measurement, grid_search, aggregation, plotting)
onto OllamaBenchmarkBase and owns nothing beyond __init__/cleanup — the real
logic for each concern lives in its own module in this package.

One grid point =
    unload everything
 -> load every model to residency, at the exact num_ctx it will be benched at
 -> verify via `ollama ps` that all of them are actually resident
 -> send one untimed warmup generation per model (resident is not warm)
 -> release every request across every model at the same instant
 -> sample VRAM while they generate, and average each model's own latency.

reuse_loaded_models=True (off by default) skips the unload/load/warmup cycle
for a rep whose configs need the same num_ctx as the previous one — but a
just-finished 60-request batch can leave the server still settling (KV-cache
slots from the previous batch not yet released), which inflates TTFT on the
very next rep without touching decode throughput. That bias defeats the point
of repeating a measurement, so it's opt-in: only turn it on if you've checked
it doesn't skew *your* server's timings, e.g. by comparing load_sec=0 reps
against load_sec>0 reps in results.csv.

With a single model spec this is the old VRAM + latency benchmark; with two or
more it is the co-residency benchmark. Same code path either way.
"""

from ollama_bench import OllamaBenchmarkBase

from .setup import SetupMixin
from .measurement import MeasurementMixin
from .grid_search import GridSearchMixin
from .aggregation import AggregationMixin
from .plotting import PlottingMixin


class MultiModelBenchmark(OllamaBenchmarkBase, SetupMixin, MeasurementMixin,
                          GridSearchMixin, AggregationMixin, PlottingMixin):
    """
    model_specs: list of dicts, one per model:
        {"model": str, "n_list": [int], "ctx_list": [int|None], "pad_list": [int]}
    ctx_list/pad_list default to [None]/[0], so adding a model doesn't silently
    multiply the grid unless you ask for it.

    Grid points = product of every model's own (n x ctx x pad) combos, so the
    count grows fast with more models; it's logged up front.

    Results land in <output_dir>/<model1>_<model2>_.../ so different
    model combinations never overwrite each other.
    """

    def __init__(self, host: str, model_specs: list, output_dir: str = ".",
                 reps: int = 1, vram_sample_interval: float = 2.0,
                 min_gpu_pct: float = 99.9, skip_on_cpu_offload: bool = True,
                 reuse_loaded_models: bool = False, **kwargs):
        specs = [self._normalize(s) for s in model_specs]
        super().__init__(host, self._results_dir(output_dir, specs), **kwargs)
        self.model_specs = specs
        self.models = [s["model"] for s in specs]
        self.reps = reps
        self.vram_sample_interval = vram_sample_interval
        self.min_gpu_pct = min_gpu_pct                  # below this a model counts as offloaded
        self.skip_on_cpu_offload = skip_on_cpu_offload  # False = bench anyway, still flagged
        self.reuse_loaded_models = reuse_loaded_models  # see module docstring — off by default

    async def cleanup(self):
        """
        Unload every model and close the HTTP client, so the GPU is left free
        for whatever runs next instead of holding VRAM for keep_alive minutes.
        Safe to call twice; never raises.
        """
        self._log("Cleaning up — unloading all models...")
        try:
            await self.unload(self.models)
            left = await self.ps_breakdown(self.models)
            resident = [f"{m} ({p['vram_gb']:.2f}GB)"
                        for m, p in left["per_model"].items() if p["loaded"]]
            self._log(f"  ⚠ still resident: {', '.join(resident)}" if resident
                      else "  GPU clear — no benchmark models resident.")
        except Exception as e:
            self._log(f"  cleanup failed (ignored): {e}")
        client = getattr(self.client, "_client", None)   # underlying httpx client
        if client is not None:
            try:
                await client.aclose()
            except Exception:
                pass
