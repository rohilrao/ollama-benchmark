"""Combined VRAM + latency benchmark for 1..N models sharing a GPU.

Split into small purpose-specific modules:
  config.py       - shared metric-name constants
  setup.py        - spec normalization, naming/tagging, blank-row templates
  measurement.py  - one grid point's load/warmup/generate/aggregate flow
  grid_search.py  - building the grid and driving it point x rep
  aggregation.py  - collapsing reps into averages; config/responses CSVs
  plotting.py     - VRAM and latency charts
  benchmark.py    - MultiModelBenchmark, composing all of the above

Import from here as before:

    from multi_model_bench import MultiModelBenchmark
"""

from .benchmark import MultiModelBenchmark

__all__ = ["MultiModelBenchmark"]
