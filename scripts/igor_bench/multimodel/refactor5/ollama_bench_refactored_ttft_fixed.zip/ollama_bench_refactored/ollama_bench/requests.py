"""One streaming generation request: timing, token accounting, and the
accumulated response text — the unit every grid-search measurement is built
from."""

import time


class RequestMixin:
    # Canonical schema of stream_request()'s numeric return values. Other
    # modules (e.g. multi_model_bench) import these instead of re-typing the
    # same key strings, so the two can't drift out of sync.
    #
    # TTFT is measured from immediately before the streaming client call to
    # the first non-empty fragment in the corresponding Ollama message field.
    # A missing field remains None; it must not be replaced with another
    # latency because that would claim an event that never happened.
    REQUEST_METRIC_FIELDS = ("wall_time_sec", "ttft_thinking_sec",
                             "ttft_content_sec", "tokens_per_sec")
    REQUEST_COUNT_FIELDS = ("output_tokens", "thinking_chunks", "content_chunks")

    async def stream_request(self, model: str, i: int, num_ctx: int = None,
                             pad_words: int = 0, gate=None) -> dict:
        """
        One streaming request, returning wall time, time-to-first-thinking-token,
        time-to-first-content-token, tok/s, thinking vs content chunk counts, and
        the full accumulated response text. Reasoning models stream thinking
        before content, so the two TTFTs can differ substantially. A model that
        emits no thinking or no content gets None for that TTFT.

        If `gate` is given the request blocks on it before starting, so every
        request across every model leaves the line at the same instant and the
        request timer starts after the gate — not at task-creation time.
        """
        options = {"temperature": 0.0}
        if num_ctx:
            options["num_ctx"] = num_ctx
        prompt = self.make_prompt(pad_words)  # built before the gate; not timed

        if gate is not None:
            await gate.wait()

        out_tokens = eval_ns = thinking_chunks = content_chunks = idx = 0
        ttft_thinking = ttft_content = None
        full_response = ""
        start = time.perf_counter()

        # With Ollama's AsyncClient, stream=True returns an async generator;
        # the request is performed when that generator is iterated. Timing the
        # complete expression therefore gives client-observed TTFT directly.
        async for chunk in await self.client.chat(
            model=model, messages=[{"role": "user", "content": prompt}],
            stream=True, options=options, keep_alive=self.keep_alive,
        ):
            now = time.perf_counter()
            think_tok = chunk.message.thinking or ""
            content_tok = chunk.message.content or ""
            if think_tok:
                thinking_chunks += 1
                if ttft_thinking is None:
                    ttft_thinking = now - start
            if content_tok:
                content_chunks += 1
                full_response += content_tok
                if ttft_content is None:
                    ttft_content = now - start
            if think_tok or content_tok:
                idx += 1
                if self.log_tokens:
                    kind = "thinking" if think_tok else "content"
                    self._log(f"[{model} R{i} T{idx} {kind}]: {(think_tok or content_tok).strip()}",
                              end=" | ", flush=True)
            if chunk.done:
                out_tokens = chunk.eval_count or 0
                eval_ns = chunk.eval_duration or 0

        wall = time.perf_counter() - start
        metrics = {"wall_time_sec": wall,
                   "ttft_thinking_sec": ttft_thinking,
                   "ttft_content_sec": ttft_content,
                   "tokens_per_sec": out_tokens / (eval_ns / 1e9) if eval_ns > 0 else 0.0}
        counts = {"output_tokens": out_tokens,
                  "thinking_chunks": thinking_chunks,
                  "content_chunks": content_chunks}
        return {**metrics, **counts,
                "request_index": i,
                "full_response": full_response,
                "char_length": len(full_response)}
